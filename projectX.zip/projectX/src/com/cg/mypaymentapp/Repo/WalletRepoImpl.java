package com.cg.mypaymentapp.Repo;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.service.WalletServiceImpl;
import com.cg.mypaymentapp.util.ConnectionSQL;

public class WalletRepoImpl implements WalletRepo {

	private Map<String, Customer> data;

	public WalletRepoImpl(Map <String, Customer> data) {
		super();
		this.data = data;
	}

	public boolean save(Customer customer) throws Exception {
		
		if (findOne(customer.getMobileNo())!= null) {
			try {
			
				String query = "insert into customer values(?,?,?)";
				PreparedStatement preparedStatement = ConnectionSQL.con
						.prepareStatement(query);
				preparedStatement.setString(1, customer.getName());
				preparedStatement.setString(2, customer.getMobileNo());
				preparedStatement.setInt(3, customer.getWallet().getBalance().intValue());
				preparedStatement.execute();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return true;

	}

	
	public Customer findOne(String mobileNo) throws SQLException {
		//System.out.println(mobileNo);
		Customer customer = new Customer();
		String query = "select * from customer where mobileno=?";
		PreparedStatement preparedStatement = ConnectionSQL.con
				.prepareStatement(query);
		preparedStatement.setString(1, mobileNo);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			
			if ( rs.getString(2).equals(mobileNo)) { 
				customer.setMobileNo(rs.getString(2));
				customer.setName(rs.getString(1));
				BigDecimal b = new BigDecimal(rs.getInt(3));
				customer.setWallet(new Wallet(b));
							}
		}
		return customer;
		

	}

	@Override
	public void update(Customer customer) throws SQLException {
		String query = "update customer set balance=? where mobileNo=?";
		PreparedStatement preparedStatement = ConnectionSQL.con
				.prepareStatement(query);
		preparedStatement.setInt(1, customer.getWallet().getBalance()
				.intValue());
		preparedStatement.setString(2, customer.getMobileNo());
		preparedStatement.executeUpdate();
	}

}

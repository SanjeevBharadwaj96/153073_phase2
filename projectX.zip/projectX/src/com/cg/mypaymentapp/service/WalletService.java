package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.sql.SQLException;

import com.cg.mypaymentapp.Exception.InsufficientBalanceException;
import com.cg.mypaymentapp.Exception.InvalidInputException;
import com.cg.mypaymentapp.beans.Customer;

public interface WalletService {
	public Customer createAccount(String name, String mobileno, BigDecimal amount) throws Exception;

	public Customer showBalance(String mobileno) throws SQLException, Exception;

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount);

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException, SQLException;

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InsufficientBalanceException, SQLException;
	
	public boolean validation(String mobileNo) throws Exception ;
	


}

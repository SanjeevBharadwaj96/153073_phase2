package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import javax.naming.InvalidNameException;

import com.cg.mypaymentapp.Exception.InsufficientBalanceException;
import com.cg.mypaymentapp.Exception.InvalidInputException;
import com.cg.mypaymentapp.Repo.WalletRepo;
import com.cg.mypaymentapp.Repo.WalletRepoImpl;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;

public class WalletServiceImpl implements WalletService {

	private WalletRepo repo;

	public WalletServiceImpl(Map<String, Customer> data) {
		repo = new WalletRepoImpl(data);
	}

	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}

	public WalletServiceImpl() {
		repo = new WalletRepoImpl(new HashMap<String, Customer>());
	}

	public Customer createAccount(String name, String mobileNo, BigDecimal amount) throws Exception {
		 Scanner console = new Scanner(System.in);
		System.out.println("in service layer");
		Customer customer = new Customer(name, mobileNo, new Wallet(amount));
		while (true) {
			try {
				if (validation(mobileNo)) {
					break;
				}

			} catch (Exception e) {
				System.err.println("invalid");
				System.out.println("enter the proper mobile number:"+ console.next());
				// e.printStackTrace();
			}
			}
			// /System.out.println(customer);
			boolean cust = repo.save(customer);
			//repo.update(customer);
		//	System.out.println(cust);
			if (cust == true) {
				return customer;
			} else {
				return null;
			}
		
		//return customer;
	}

	public boolean validation(String mobileNo) throws Exception {

		String pattern = "[1-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]";
		if (mobileNo.matches(pattern)) {
			return true;

		} else
			throw new InvalidInputException("enter proper number");

	}

	public Customer showBalance(String mobileNo) throws Exception {
		Customer customer = repo.findOne(mobileNo);

		/*if (validation(mobileNo)) {

			if (customer!= null) {
				System.out.println(customer);
				return customer;
			}
			else {
				throw new InvalidInputException("invalid ");
		
			}
		}*/
		return customer;
	

	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount)
			throws InvalidInputException {
		try {
			Customer customer21 = repo.findOne(sourceMobileNo);
			Customer customer22 = repo.findOne(targetMobileNo);
			if ((customer21 != null) && (customer22 != null)) {
				Customer dcustomer=depositAmount(targetMobileNo, amount);
				Customer wcustomer=withdrawAmount(sourceMobileNo, amount);
				repo.update(dcustomer);
				repo.update(wcustomer);
				return dcustomer;
			}
			

		} catch (Exception e) {
			System.err.println("invalid input details");

		}
		return null;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException, SQLException {
		Customer dcustomer = repo.findOne(mobileNo);
		try {
			if (dcustomer != null) {
				Wallet iAmount = dcustomer.getWallet();
				BigDecimal updatedBalance = iAmount.getBalance().add(amount);
				Wallet wallet = new Wallet(updatedBalance);
				dcustomer.setWallet(wallet);
				repo.update(dcustomer);
				return dcustomer;
			} else {
				return null;
			}
		} catch (Exception e) {
			System.err.println("invalid input details");
		}
		return null;
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount)
			throws InsufficientBalanceException, SQLException {

		try {
			Customer wcustomer = repo.findOne(mobileNo);
			if (wcustomer != null) {
				Wallet iAmount = wcustomer.getWallet();
				BigDecimal updatedBalance = iAmount.getBalance().subtract(amount);
				Wallet wallet = new Wallet(updatedBalance);
				int ubal = Integer.parseInt(updatedBalance.toString());
				if (ubal < 0) {
					System.err.println("insufficient balance");
					return null;
				}
				wcustomer.setWallet(wallet);
				repo.update(wcustomer);
				return wcustomer;
			} else {
				return null;
			}
		} catch (Exception e) {
			System.err.println("insufficient funds");
			return null;
		}
	}

}
